package com.admin.service.impl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.admin.dao.AccountRepository;
import com.admin.dao.UserRepository;

@Service
public class MailServiceImpl {
	
	@Autowired
	UserRepository userDAO;
	
	@Autowired
	AccountRepository  accountDAO;
	
}
